package com.sergiohscl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
